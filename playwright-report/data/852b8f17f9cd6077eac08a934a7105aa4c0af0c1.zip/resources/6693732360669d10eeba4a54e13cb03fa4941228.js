(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__59c372b1._.css",
  "static/chunks/personal-portfolio_7d99ff87._.js"
],
    source: "dynamic"
});

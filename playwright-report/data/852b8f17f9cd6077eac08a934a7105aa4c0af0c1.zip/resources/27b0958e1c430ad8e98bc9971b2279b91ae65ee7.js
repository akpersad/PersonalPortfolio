(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0d299cb9._.js",
  "static/chunks/3aa96_next_dist_compiled_react-dom_e2e35bc1._.js",
  "static/chunks/3aa96_next_dist_compiled_next-devtools_index_8a2f75c9.js",
  "static/chunks/3aa96_next_dist_compiled_a5ee4f9d._.js",
  "static/chunks/3aa96_next_dist_client_ae7d3f1a._.js",
  "static/chunks/3aa96_next_dist_ca9e77a4._.js",
  "static/chunks/3aa96_@swc_helpers_cjs_bc454648._.js"
],
    source: "entry"
});
